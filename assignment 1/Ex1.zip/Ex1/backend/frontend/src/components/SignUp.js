import React, { useState } from 'react';
import axios from 'axios';

function SignUp() {
    const [formData, setFormData] = useState({
        firstName: '', lastName: '', studentNumber: '', address: '', city: '', phoneNumber: '', program: '', semester: '', email: '', password: ''
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSignUp = () => {
        axios.post('http://localhost:5000/api/signup', formData)
            .then(response => alert('Sign up successful'))
            .catch(error => console.error('Error signing up:', error));
    };

    return (
        <div className="container">
            <h1>Sign Up</h1>
            <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} placeholder="Enter first name" />
            <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} placeholder="Enter last name" />
            <input type="text" name="studentNumber" value={formData.studentNumber} onChange={handleChange} placeholder="Enter student number" />
            <input type="text" name="address" value={formData.address} onChange={handleChange} placeholder="Enter address" />
            <input type="text" name="city" value={formData.city} onChange={handleChange} placeholder="Enter city" />
            <input type="text" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} placeholder="Enter phone number" />
            <input type="text" name="program" value={formData.program} onChange={handleChange} placeholder="Enter program" />
            <input type="text" name="semester" value={formData.semester} onChange={handleChange} placeholder="Enter semester" />
            <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Enter email" />
            <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Enter password" />
            <button onClick={handleSignUp}>Sign Up</button>
        </div>
    );
}

export default SignUp;
