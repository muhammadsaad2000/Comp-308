import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Admin() {
    const [students, setStudents] = useState([]);
    const [courses, setCourses] = useState([]);
    const [studentsInCourse, setStudentsInCourse] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5000/api/students')
            .then(response => setStudents(response.data))
            .catch(error => console.error('Error fetching students:', error));
        
        axios.get('http://localhost:5000/api/courses')
            .then(response => setCourses(response.data))
            .catch(error => console.error('Error fetching courses:', error));
    }, []);

    const handleGetStudentsInCourse = (courseName) => {
        axios.get(`http://localhost:5000/api/courses/${courseName}/students`)
            .then(response => setStudentsInCourse(response.data))
            .catch(error => console.error('Error fetching students in course:', error));
    };

    return (
        <div className="container">
            <h1>Admin Panel</h1>
            <h2>All Students</h2>
            <ul>
                {students.map(student => (
                    <li key={student.studentNumber}>{student.firstName} {student.lastName}</li>
                ))}
            </ul>
            <h2>All Courses</h2>
            <ul>
                {courses.map(course => (
                    <li key={course.name}>
                        {course.name}
                        <button onClick={() => handleGetStudentsInCourse(course.name)}>View Students</button>
                    </li>
                ))}
            </ul>
            <h2>Students in Course</h2>
            <ul>
                {studentsInCourse.map(student => (
                    <li key={student.studentNumber}>{student.firstName} {student.lastName}</li>
                ))}
            </ul>
        </div>
    );
}

export default Admin;
