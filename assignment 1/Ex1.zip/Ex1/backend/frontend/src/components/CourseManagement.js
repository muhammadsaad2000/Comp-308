import React, { useState, useEffect } from 'react';
import axios from 'axios';

function CourseManagement() {
    const [courses, setCourses] = useState([]);
    const [courseName, setCourseName] = useState('');

    useEffect(() => {
        fetchCourses();
    }, []);

    const fetchCourses = () => {
        axios.get('http://localhost:5000/api/courses', { headers: { Authorization: localStorage.getItem('token') } })
            .then(response => setCourses(response.data))
            .catch(error => console.error('Error fetching courses:', error));
    };

    const addCourse = () => {
        axios.post('http://localhost:5000/api/courses', { courseName }, { headers: { Authorization: localStorage.getItem('token') } })
            .then(response => setCourses([...courses, response.data]))
            .catch(error => console.error('Error adding course:', error));
    };

    return (
        <div className="container">
            <h1>Course Management</h1>
            <ul>
                {courses.map(course => (
                    <li key={course.id}>{course.courseName}</li>
                ))}
            </ul>
            <input
                type="text"
                value={courseName}
                onChange={(e) => setCourseName(e.target.value)}
                placeholder="Enter course name"
            />
            <button onClick={addCourse}>Add Course</button>
        </div>
    );
}

export default CourseManagement;
