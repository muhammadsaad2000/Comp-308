import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function SignIn() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleSignIn = () => {
        axios.post('http://localhost:5000/api/signin', { email, password })
            .then(response => {
                localStorage.setItem('token', response.data.token);
                const userRole = JSON.parse(atob(response.data.token.split('.')[1])).role;
                if (userRole === 'admin') {
                    navigate('/admin');
                } else {
                    navigate('/courses');
                }
            })
            .catch(error => console.error('Error signing in:', error));
    };

    return (
        <div className="container">
            <h1>Sign In</h1>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter email" />
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter password" />
            <button onClick={handleSignIn}>Sign In</button>
        </div>
    );
}

export default SignIn;
