import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import CourseManagement from './components/CourseManagement';
import Admin from './components/Admin';
import './App.css';

function App() {
    return (
        <Router>
            <div>
                <Switch>
                    <Route path="/signin" component={SignIn} />
                    <Route path="/signup" component={SignUp} />
                    <Route path="/courses" component={CourseManagement} />
                    <Route path="/admin" component={Admin} />
                    <Route path="/" exact component={SignIn} />
                </Switch>
            </div>
        </Router>
    );
}

export default App;
