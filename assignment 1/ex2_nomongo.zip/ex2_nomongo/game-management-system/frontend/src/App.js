import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import GameList from './components/GameList';
import AddGame from './components/AddGame';
import RemoveGame from './components/RemoveGame';
import GameDetails from './components/GameDetails';
import NotFound from './components/NotFound';

const App = () => {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/games" element={<GameList />} />
          <Route path="/games/add" element={<AddGame />} />
          <Route path="/games/remove" element={<RemoveGame />} />
          <Route path="/games/:id" element={<GameDetails />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
