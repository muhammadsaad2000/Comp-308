import React from 'react';
import { Link } from 'react-router-dom';

const RemoveGame = () => {
  return (
    <div>
      <h2>Remove Game</h2>
      <p>This is the Remove Game page. Remove games from your collection here.</p>
      <Link to="/games">Back to Game List</Link>
    </div>
  );
};

export default RemoveGame;
