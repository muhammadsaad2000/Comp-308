import React from 'react';
import { useParams, Link } from 'react-router-dom';

const GameDetails = () => {
  const { id } = useParams();

  return (
    <div>
      <h2>Game Details</h2>
      <p>This is the details page for game with ID: {id}</p>
      <Link to="/games">Back to Game List</Link>
    </div>
  );
};

export default GameDetails;
