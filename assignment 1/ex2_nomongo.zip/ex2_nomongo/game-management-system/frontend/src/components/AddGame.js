import React from 'react';
import { Link } from 'react-router-dom';

const AddGame = () => {
  return (
    <div>
      <h2>Add Game</h2>
      <p>This is the Add Game page. Add your favorite games here.</p>
      <Link to="/games">Back to Game List</Link>
    </div>
  );
};

export default AddGame;
