// frontend/src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import GameList from './components/GameList';
import AddGame from './components/AddGame';
import RemoveGame from './components/RemoveGame';
import ThreeJsBackground from './threeJsComponents/ThreeJsBackground';
import './App.css';

const App = () => {
  return (
    <Router>
      <div className="App">
        <ThreeJsBackground />
        <Switch>
          <Route path="/register" component={Register} />
          <Route path="/login" component={Login} />
          <Route path="/games" component={GameList} />
          <Route path="/add-game" component={AddGame} />
          <Route path="/remove-game" component={RemoveGame} />
        </Switch>
      </div>
    </Router>
  );
};

export default App;
