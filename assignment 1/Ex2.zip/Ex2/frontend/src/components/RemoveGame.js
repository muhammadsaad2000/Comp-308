// frontend/src/components/RemoveGame.js
import React, { useState } from 'react';
import axios from 'axios';

const RemoveGame = () => {
  const [gameId, setGameId] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/api/games/removeUserGame', { gameId });
      console.log(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Remove Game</h2>
      <input type="text" placeholder="Game ID" value={gameId} onChange={(e) => setGameId(e.target.value)} />
      <button type="submit">Remove Game</button>
    </form>
  );
};

export default RemoveGame;
