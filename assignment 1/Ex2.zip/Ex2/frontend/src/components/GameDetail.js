// frontend/src/components/GameDetail.js
import React from 'react';

const GameDetail = ({ game }) => {
  return (
    <div>
      <h2>{game.title}</h2>
      <p>{game.description}</p>
      <p>Genre: {game.genre}</p>
      <p>Platform: {game.platform}</p>
      <p>Release Year: {game.releaseYear}</p>
      <p>Developer: {game.developer}</p>
      <p>Rating: {game.rating}</p>
    </div>
  );
};

export default GameDetail;
