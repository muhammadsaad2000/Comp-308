// frontend/src/components/GameList.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const GameList = () => {
  const [games, setGames] = useState([]);

  useEffect(() => {
    const fetchGames = async () => {
      try {
        const res = await axios.get('/api/games/all');
        setGames(res.data);
      } catch (err) {
        console.error(err);
      }
    };

    fetchGames();
  }, []);

  return (
    <div>
      <h2>Game List</h2>
      <ul>
        {games.map((game) => (
          <li key={game._id}>{game.title}</li>
        ))}
      </ul>
    </div>
  );
};

export default GameList;
