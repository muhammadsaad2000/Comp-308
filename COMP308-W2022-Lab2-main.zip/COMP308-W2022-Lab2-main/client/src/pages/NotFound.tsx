export default function NotFound(): JSX.Element {
  return (
    <main>
      <h1>404 Page Not Found</h1>
    </main>
  );
}
